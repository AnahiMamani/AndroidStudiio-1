package com.example.atvaula

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import com.example.atvaula.ui.theme.ATVAULATheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ATVAULATheme {
                PrimeiraTela()
            }
        }
    }
}

@Composable
fun PrimeiraTela(){
    Scaffold (
        topBar =  {
            TopAppBar(
                backgroundColor = Color.Blue
            ) {
            Text(
                text = "TESTE DE TITULO",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
            ) {

    }
}

@Preview
@Composable
fun PrimeiraTelaPreview() {
    PrimeiraTela()

}